// import React from "react";
// import { Container, Row, Col } from "../Grid";

// export const BlogPreviewItem = props => (
//     <Container>
//         <Row>
//         <div className="image1">
//         <Col size="xs-4 sm-4">
//           <h3>Blog #1</h3>
//           <p>This is a blog about blogs</p>
//           {/* <a rel="noreferrer noopener" target="_blank" href={props.href}>Go to recipe!</a> */}
//         </Col>
//         </div>
//         <div className="image2">
//             <Col size="xs-4 sm-4">
//             <h3>Blog #2</h3>
//             <p>This is a blog about blogs</p>
//             {/* <a rel="noreferrer noopener" target="_blank" href={props.href}>Go to recipe!</a> */}
//             </Col>
//         </div>
//         <div className="image3">
//             <Col size="xs-4 sm-4">
//             <h3>Blog #1</h3>
//             <p>This is a blog about blogs</p>
//             {/* <a rel="noreferrer noopener" target="_blank" href={props.href}>Go to recipe!</a> */}
//             </Col>
//         </div>
//       </Row>
//     </Container>
// );
